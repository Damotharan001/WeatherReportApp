//
//  Constant.swift
//  WeatherForecastApp
//
//  Created by Damotharan KG on 11/12/23.
//

import Foundation
enum Constant{
    static let apiKey = "97559af9f2aa592ebfc7bb44cb6c60ee"
    static let baseURL = "https://api.openweathermap.org/data/2.5/"
    
}
