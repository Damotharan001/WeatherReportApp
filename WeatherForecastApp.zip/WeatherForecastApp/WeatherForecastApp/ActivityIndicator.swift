//
//  ActivityIndicator.swift
//  WeatherForecastApp
//
//  Created by Damotharan KG on 15/12/23.
//

import Foundation
class ActivityIndicators{
    
}
